

                                    ============================
                                      R E A D M E    N O T E S
                                    ============================

                                   Broadcom  NetXtreme II 10 Gigabit
                                           Ethernet Driver
                                                for
                                              DOS ODI

                               Copyright (c) 2002-2009 Broadcom Corporation
                                        All rights reserved.



For use on PCs running DOS version 6.22 only. 

To use to login to a Novell Netware Server use the Novell ZENWorks Starter Pack
to setup and configure your PC.

To login to NETBEUI/NDIS environments please use Novell's ODINSUP.COM protocol
as a link between the BNX2EV DOS ODI driver and the NETBEUI/NDIS protocols.

CUSTOM KEYWORDS for net.cfg:

BUSNUM 
DEVNUM
FUNCNUM
LINESPEED (FUTURE IMPLEMENTATION)
DUPLEX (FUTURE IMPLEMENTATION)


BUSNUM:

This hexadecimal parameter, range from 0-255, specifies the PCI bus number on which the
ethernet controller is located.

DEVNUM:

This hexadecimal parameter, range from 0-31, specifies the PCI device number assigned
to the ethernet controller.

FUNCNUM:

This hexadecimal parameter, range from 0-7, specifies the PCI function or port number
assigned to the ethernet controller.

LINESPEED:

This decimal parameter, 10 or 100, specifies the speed of the network connection.

NOTE: According to IEEE specifications, copper line speed of 1000 can not be forced and its
      only achievable by auto negotiation.

DUPLEX:

This string parameter, HALF or FULL, specifies duplex mode on the ethernet controller.
The Linespeed parameter must be set when this keyword is used. If neither the Duplex
nor the Linespeed paramaters are specified the ethernet controller will default to
autonegotiate mode.


NOTE: The first three keywords are used concurrently and have been included for 
      manufacturing purposes.  Do not use them unless you are familiar with PCI
      device configuration.
      These three keywords are needed if multiple boards are on a system 
      and (a) specific adapter/s need to be loaded in specific order.

      In addition to these three keywords, the driver has ability to detect and load on
      the NIC that has a good link. In case of multiple NICs with multiple good links,
      its will loads on the first NIC found with good link.


A PCI device scan utility can also be used to find this information.
The NET.CFG file expects hexadecimal values.

Example:
	If the driver loads on a single adapter, the values displayed on screen
	can be used in the NET.CFG file.
	If a PCI scan utility displays card 1 at bus 4 and device 11(hex) and
	card 3 at bus 3 device 13 hex then the following would be put into net.cfg
	to load card 3 first and optionally load card 1 second:


	LINK DRIVER BNX2EV
		BUSNUM 3
		DEVNUM 13 (13 hex = 19 decimal)
	LINK DRIVER BNX2EV
		BUSNUM 4
		DEVNUM 11 (11 hex = 17 decimal)

The driver will always load on the first device detected when these keywords are
not used.

Example of the use of these key words:

	LINK DRIVER BNX2EV
                BUSNUM 3
		DEVNUM 13 ( 13 hex = 19 decimal)
		LINESPEED 100
                DUPLEX FULL
                 

NOTE:
      If the connection fails, set the Spanning Tree Protocol (STP) option on the switch to "off".