NDK Graveyard Component


Table of Contents
     1.0  Support Status
     2.0  Additional Information
     3.0  Legal Info


1.0  Support Status

     This NDK Graveyard Component is unsupported.


2.0  Additional Information

     For specific details about this component, 
     please refer to any readmes that were
     included in the component download. 


3.0  Legal Info

     You must accept (and are accountable for) any license
     agreements (such as license.txt) included in the download
     for this component.   

     Novell, Inc. makes no representations or warranties
     with respect to the contents or use of this
     documentation, and specifically disclaims any express
     or implied warranties of merchantability or fitness
     for any particular purpose. Further, Novell, Inc.
     reserves the right to revise this publication and to
     make changes to its content, at any time, without
     obligation to notify any person or entity of such
     revisions or changes.

     Further, Novell, Inc. makes no representations or
     warranties with respect to any software, and
     specifically disclaims any express or implied
     warranties of merchantability or fitness for any
     particular purpose. Further, Novell, Inc. reserves the
     right to make changes to any and all parts of Novell
     software, at any time, without any obligation to
     notify any person or entity of such changes.

     You may not export or re-export this product in
     violation of any applicable laws or regulations
     including, without limitation, U.S. export regulations
     or the laws of the country in which you reside.

     Copyright � 2003 Novell, Inc. All rights
     reserved. No part of this publication may be
     reproduced, photocopied, stored on a retrieval system,
     or transmitted without the express written consent of
     the publisher.

     Novell is a registered trademark of Novell, Inc. in
     the United States and other countries.

     All third-party products are the property of their
     respective owners.


