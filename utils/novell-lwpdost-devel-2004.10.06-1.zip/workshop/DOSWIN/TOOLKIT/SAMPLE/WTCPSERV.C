/*
 * Example TCP server for DOS Lan Workplace 4.0 Transport Socket API.
 * 
 * It accepts connections on TCP port 7, reads data from the socket and 
 * echoes it back until the client closes.  This program never exits.
 */

#include <windows.h>
#include <stdio.h>
#include <process.h>

#include <sys\socket.h>
#include "wtcpserv.h"

long FAR PASCAL WTcpServWndProc(HWND, unsigned, WORD, LONG);
VOID AlertUser (HWND, LPSTR);
BOOL InitWindow(HANDLE);

HANDLE          hInst;
HANDLE          hLibInstance;

#define	ECHO_PORT	7
#define	MAX_SOCKETS	32
#define	BUFFER_SIZE	1024

char            buffer[BUFFER_SIZE];
int             in_use[MAX_SOCKETS];
struct timeval  seltime;
fd_set          readfds;


char            szBuffer[256];	/* used for messages */

void            read_and_echo(HWND, int);
void            make_new_echo(HWND, int);

int PASCAL 
WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
	HANDLE          hInstance;
	HANDLE          hPrevInstance;
	LPSTR           lpCmdLine;
	int             nCmdShow;

{

	HWND            hWnd;
	MSG             msg;

	if (!hPrevInstance)
		if (!InitWindow(hInstance))
			return (NULL);

	hInst = hLibInstance = hInstance;

	hWnd = CreateWindow("TestClass",
			    "TCP Echo Server",
			    WS_OVERLAPPEDWINDOW,
			    CW_USEDEFAULT,
			    CW_USEDEFAULT,
			    CW_USEDEFAULT,
			    CW_USEDEFAULT,
			    NULL,
			    NULL,
			    hInstance,
			    NULL);

	if (!hWnd)
		return (NULL);

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	while (GetMessage(&msg, NULL, NULL, NULL)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return (msg.wParam);

}

VOID 
wtcp_serv(hWnd)
	HWND            hWnd;

{
	int             s, x;
	struct sockaddr_in addr;
	MSG		msg;

	for (x = 0; x < MAX_SOCKETS; x++) {
		in_use[x] = 0;
	}

	if ((s = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		AlertUser(hWnd, (LPSTR) "Socket open failed.");
		exit(1);
	}
	addr.sin_family = AF_INET;
	addr.sin_port = htons(ECHO_PORT);
	addr.sin_addr.s_addr = 0;

	if (bind(s, (SADDR_PTR)&addr, sizeof(addr)) < 0) {
		(void) soclose(s);
		AlertUser(hWnd, (LPSTR) "Bind failed.");
		exit(1);
	}
	if (listen(s, 5) < 0) {
		(void) soclose(s);
		AlertUser(hWnd, (LPSTR) "Listen failed.");
		exit(1);
	}
	AlertUser(hWnd,
	  (LPSTR) "TCP echo server started.");

	for (;;) {

		FD_ZERO((FDSET_PTR)&readfds);

		seltime.tv_sec = 1;
		seltime.tv_usec = 0;

		FD_SET(s, (FDSET_PTR)&readfds);
		for (x = 0; x < MAX_SOCKETS; x++) {
			if (in_use[x]) {
				FD_SET(x, (FDSET_PTR)&readfds);
			}
		}

		if (!select(MAX_SOCKETS,
			    (FDSET_PTR)&readfds, (FDSET_PTR) 0, (FDSET_PTR) 0,
			    (TIMEVAL_PTR)&seltime)) {
    		if (PeekMessage (&msg, NULL, 0, 0, PM_REMOVE)) {
	    		if (msg.message == WM_QUIT) {
		    		(void) soclose(s);
			    	return;
			    }
			    TranslateMessage (&msg);
			    DispatchMessage (&msg);
		    }

			continue;
		}
		for (x = 0; x < MAX_SOCKETS; x++) {
			if (FD_ISSET(x, (FDSET_PTR)&readfds)) {
				if (x != s) {
					read_and_echo(hWnd, x);
				} else {
					make_new_echo(hWnd, x);
				}
			}
		}
	}
}

/*
 * Read and echo the input from a socket
 */

void 
read_and_echo(hWnd, s)
	HWND            hWnd;
	int             s;
{
	int             rc, len;

	if ((len = soread(s, (LPSTR) buffer, sizeof(buffer))) <= 0) {
		in_use[s] = 0;
		(void) soclose(s);
	} else {
		rc = sowrite(s, (LPSTR) buffer, len);
		if (rc < 0) {
			in_use[s] = 0;
			(void) soclose(s);
		}
	}
}

/*
 * Make a new socket using accept()
 */

void
make_new_echo(hWnd, s)
	HWND            hWnd;
	int             s;
{
	int             ns;
	struct sockaddr_in peer;
	int             peersize = sizeof(peer);
	char            szIPAddr[16];

	if ((ns = accept(s,(SADDR_PTR)&peer, (LPINT)&peersize)) < 0) {
		AlertUser(hWnd, (LPSTR) "WARNING: Active connections: accept");
		exit(1);
	}
	in_use[ns] = 1;
}

long FAR PASCAL 
WTcpServWndProc(hWnd, message, wParam, lParam)
	HWND            hWnd;
	unsigned        message;
	WORD            wParam;
	LONG            lParam;

{
	FARPROC         lpProcAbout;
	HANDLE          hTemp;
	HANDLE          hHost;
	LPSTR           lpTemp;
	char            szIPAddr[16];
	char            szHost[32];

	switch (message) {

	case WM_COMMAND:
		switch (wParam) {

		case IDM_WTCPSERV:
			wtcp_serv(hWnd);
			break;

		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;

		}
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;

	default:
		return (DefWindowProc(hWnd, message, wParam, lParam));
	}
	return (NULL);
}


void 
AlertUser(hWnd, lpszWarning)
	HWND            hWnd;
	LPSTR           lpszWarning;

{
	MessageBox(hWnd,
		   lpszWarning,
		   "XFM",
		   MB_OK | MB_ICONEXCLAMATION);

}				/* end Warning () */

BOOL 
InitWindow(hInstance)
	HANDLE          hInstance;

{
	WNDCLASS        WndClass;
	BOOL            bSuccess;

	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	WndClass.lpfnWndProc = WTcpServWndProc;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hInstance = hInstance;
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hbrBackground = COLOR_WINDOW + 1;
	WndClass.lpszMenuName = (LPSTR) "TestMenu";
	WndClass.lpszClassName = (LPSTR) "TestClass";

	return (RegisterClass((PWNDCLASS) & WndClass));
}
