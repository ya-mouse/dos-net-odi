/*
 * Example TCP client for DOS Lan Workplace 4.0 Transport Socket API.
 * 
 * It opens a connection with an echo server at TCP port 7, sends data 
 * and waits for all data to be echoed before closing the socket.
 */

#include <windows.h>
#include <stdio.h>
#include <process.h>

#include <sys\socket.h>
#include "wtcpclnt.h"

long FAR PASCAL WTcpClntWndProc(HWND, unsigned, WORD, LONG);
BOOL FAR PASCAL Get_hostname(HWND, unsigned, WORD, LONG);
VOID AlertUser (HWND, LPSTR);
BOOL InitWindow(HANDLE);

HANDLE          hInst;
HANDLE          hLibInstance;

#define	ECHO_PORT	7
#define	NUM_PKTS	10
#define	BUFFER_SIZE	1024
#define	TOTAL_BYTES	NUM_PKTS * BUFFER_SIZE

char            buffer[BUFFER_SIZE];
struct timeval  seltime;
fd_set          readfds, writefds;
int             pkts_sent = 0;
int             bytes_recv = 0;

char            szBuffer[256];	/* used for messages */
char            hname_buf[256] = {0};	/* Hostname */

int PASCAL 
WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
	HANDLE          hInstance;
	HANDLE          hPrevInstance;
	LPSTR           lpCmdLine;
	int             nCmdShow;

{

	HWND            hWnd;
	MSG             msg;

	if (!hPrevInstance)
		if (!InitWindow(hInstance))
			return (NULL);

	hInst = hLibInstance = hInstance;

	hWnd = CreateWindow("TestClass",
			    "TCP Echo Client",
			    WS_OVERLAPPEDWINDOW,
			    CW_USEDEFAULT,
			    CW_USEDEFAULT,
			    CW_USEDEFAULT,
			    CW_USEDEFAULT,
			    NULL,
			    NULL,
			    hInstance,
			    NULL);

	if (!hWnd)
		return (NULL);

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	while (GetMessage(&msg, NULL, NULL, NULL)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return (msg.wParam);

}

VOID 
tcp_echo(hWnd)
	HWND            hWnd;

{
	int             s, rc, len;
	LPSTR           lpTemp;
	HANDLE          hTemp;
	unsigned long   remote_ip;
	struct sockaddr_in addr;
	MSG		msg;

	hTemp = GlobalAlloc(GMEM_MOVEABLE, (DWORD) 128);
	if (hTemp == NULL) {
		AlertUser(hWnd, (LPSTR) "Memory allocation failed.");
		exit(1);
	}
	/* query for a machine in a different domain */
	lpTemp = (LPSTR) GlobalLock(hTemp);
	lstrcpy(lpTemp, (LPSTR) hname_buf);
	GlobalUnlock(hTemp);

	if ((remote_ip = rhost((LPHANDLE) & hTemp)) == -1) {
		lpTemp = (LPSTR) GlobalLock(hTemp);
		sprintf(szBuffer, "Unknown or illegal hostname = %s", lpTemp);
		AlertUser(hWnd, (LPSTR) szBuffer);
		GlobalUnlock(hTemp);
		GlobalFree(hTemp);
		exit(1);
	}
	if ((s = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		AlertUser(hWnd, (LPSTR) "Socket open failed.");
		exit(1);
	}
	addr.sin_family = AF_INET;
	addr.sin_port = htons(ECHO_PORT);
	addr.sin_addr.s_addr = remote_ip;

	if (connect(s, (SADDR_PTR)&addr, sizeof(addr)) < 0) {
		(void) soclose(s);
		AlertUser(hWnd, (LPSTR) "Connect failed.");
		exit(1);
	}
	while (bytes_recv < TOTAL_BYTES) {

		FD_ZERO((FDSET_PTR)&readfds);
		FD_ZERO((FDSET_PTR)&writefds);
		FD_SET(s, (FDSET_PTR)&readfds);
		FD_SET(s, (FDSET_PTR)&writefds);
		seltime.tv_sec = 1;
		seltime.tv_usec = 0;

		if (!select(s + 1,
			    (FDSET_PTR)&readfds, (FDSET_PTR)&writefds, (FDSET_PTR)0,
			    (TIMEVAL_PTR)&seltime)) {
     		if (PeekMessage (&msg, NULL, 0, 0, PM_REMOVE)) {
		    	if (msg.message == WM_QUIT) {
			    	(void) soclose(s);
				    return;
			    }
			    TranslateMessage (&msg);
			    DispatchMessage (&msg);
		    }

			continue;
		}
		if (pkts_sent < NUM_PKTS) {
			if (FD_ISSET(s, (FDSET_PTR)&writefds)) {
				rc = sowrite(s, (LPSTR)buffer, BUFFER_SIZE);
				if (rc < 0) {
					(void) soclose(s);
					exit(1);
				}
				pkts_sent++;
			}
		}
		if (FD_ISSET(s, (FDSET_PTR)&readfds)) {
			if ((len = soread(s, (LPSTR)buffer, BUFFER_SIZE)) > 0) {
				bytes_recv += len;
			}
		}
	}

	sprintf(szBuffer, "Sent and received %d bytes\n", TOTAL_BYTES);
	AlertUser(hWnd, (LPSTR) szBuffer);
	(void) soclose(s);

}

long FAR PASCAL 
WTcpClntWndProc(hWnd, message, wParam, lParam)
	HWND            hWnd;
	unsigned        message;
	WORD            wParam;
	LONG            lParam;

{
	FARPROC         lpProcHostname;
	FARPROC         lpProcAbout;
	HANDLE          hTemp;
	HANDLE          hHost;
	LPSTR           lpTemp;
	char            szIPAddr[16];
	char            szHost[32];

	switch (message) {

	case WM_COMMAND:
		switch (wParam) {

		case IDM_START:
			lpProcHostname = MakeProcInstance(Get_hostname, hInst);
			DialogBox(hInst, "GetName", hWnd, lpProcHostname);
			FreeProcInstance(lpProcHostname);
			tcp_echo(hWnd);
			break;

		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;

		}
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;

	default:
		return (DefWindowProc(hWnd, message, wParam, lParam));
	}
	return (NULL);
}

BOOL FAR PASCAL 
Get_hostname(hDlg, message, wParam, lParam)
	HWND            hDlg;
	unsigned        message;
	WORD            wParam;
	LONG            lParam;

{
	switch (message) {
	case WM_INITDIALOG:
		SetDlgItemText(hDlg, HOSTNAME, (LPSTR) hname_buf);
		return (TRUE);
		break;
	case WM_COMMAND:
		if (wParam == IDOK) {
			GetDlgItemText(hDlg, HOSTNAME, (LPSTR) hname_buf, 255);
			EndDialog(hDlg, TRUE);
			return (TRUE);
		}
		break;
	}
	return (FALSE);
}

void 
AlertUser(hWnd, lpszWarning)
	HWND            hWnd;
	LPSTR           lpszWarning;

{
	MessageBox(hWnd,
		   lpszWarning,
		   "TCP Client",
		   MB_OK | MB_ICONEXCLAMATION);

}				/* end Warning () */


BOOL 
InitWindow(hInstance)
	HANDLE          hInstance;

{
	WNDCLASS        WndClass;
	BOOL            bSuccess;

	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	WndClass.lpfnWndProc = WTcpClntWndProc;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hInstance = hInstance;
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hbrBackground = COLOR_WINDOW + 1;
	WndClass.lpszMenuName = (LPSTR) "TestMenu";
	WndClass.lpszClassName = (LPSTR) "TestClass";

	return (RegisterClass((PWNDCLASS) & WndClass));
}

