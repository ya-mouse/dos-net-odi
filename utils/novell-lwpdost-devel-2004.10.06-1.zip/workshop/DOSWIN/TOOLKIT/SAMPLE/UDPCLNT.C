/*
 * Example UDP client for DOS Lan Workplace 4.0 Transport Socket API.
 * 
 * It sends datagrams to an echo server at UDP port 7, and waits for replies.
 * Because UDP is an unreliable protocol, the client cannot assume that a
 * reply will arrive.  The client waits for a maximum of one second 
 * (using select) before proceeding on to the next send.
 *
 * To compile and link (using Microsoft C):
 * 
 *	cl /W3 udpclnt.c /link slibsock.lib
 * 
 * 
 * To execute:
 * 
 *	udpclnt <IP address>
 */

#include <stdio.h>
#include <process.h>

#include <sys/socket.h>

#define	ECHO_PORT	7
#define	NUM_PKTS	10
#define	BUFFER_SIZE	1024

char            buffer[BUFFER_SIZE];
struct timeval  seltime;
fd_set          readfds;
int             pkts_sent = 0;
int             pkts_recv = 0;

void            main(int, char **);

/*
 * Main routine
 */

void
main(argc, argv)
	int             argc;
	char          **argv;
{
	int             s, rc;
	char           *hostname = 0;
	unsigned long   remote_ip;
	struct sockaddr_in addr;


	if (!loaded()) {
		printf("The TCP/IP protocol stack is not loaded\n");
		exit(1);
	}

	if (argc != 2) {
		printf("usage: udpclnt <IP address>\n");
		exit(1);
	}

	hostname = argv[1];
	if ((remote_ip = rhost(&hostname)) == -1) {
		printf("unknown or illegal hostname = %s", argv[1]);
		exit(1);
	}

	if ((s = socket(PF_INET, SOCK_DGRAM, 0)) < 0) {
		soperror("socket");
		exit(1);
	}

	bzero ((char *)&addr, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(ECHO_PORT);
	addr.sin_addr.s_addr = remote_ip;

	while (pkts_sent < NUM_PKTS ) {

		rc = sendto (s, buffer, BUFFER_SIZE, 0,
                     (struct sockaddr *)&addr, sizeof(addr));
		if (rc < 0) {
			soperror ("sendto");
			(void) soclose (s);
			exit (1);
		}
		pkts_sent ++;

		FD_ZERO(&readfds);

		seltime.tv_sec  = 1;
		seltime.tv_usec = 0;

		FD_SET(s, &readfds);

		if (!select(s + 1,
			    &readfds, (fd_set *) 0, (fd_set *) 0,
			    &seltime)) {
			continue;
		}

		rc = soread(s, buffer, BUFFER_SIZE);
		if (rc < 0) {
			soperror ("soread");
			(void) soclose (s);
			exit (1);
		}

		pkts_recv ++;
	}

	(void) soclose(s);

	printf ("%d UDP Packets Sent, %d Replies Received\n",
		pkts_sent, pkts_recv);
}
