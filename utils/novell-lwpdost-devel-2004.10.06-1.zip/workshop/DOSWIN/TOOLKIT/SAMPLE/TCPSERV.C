/*
 * Example TCP server for DOS Lan Workplace 4.0 Transport Socket API.
 * 
 * It accepts connections on TCP port 7, reads data from the socket and echoes
 * it back until the client closes.  This program never exits.
 * 
 * To compile and link (using Microsoft C):
 * 
 *	cl /W3 tcpserv.c /link slibsock.lib
 * 
 * 
 * To execute:
 * 
 *	tcpserv
 */

#include <stdio.h>
#include <process.h>

#include <sys/socket.h>

#define	ECHO_PORT	7
#define	MAX_SOCKETS	32
#define	BUFFER_SIZE	1024

char            buffer[BUFFER_SIZE];
int             in_use[MAX_SOCKETS];
struct timeval  seltime;
fd_set          readfds;

void            main(void);
void            read_and_echo(int);
void            make_new_echo(int);

/*
 * Main routine
 */

void 
main()
{
	int             s, x;
	struct sockaddr_in addr;


	if (!loaded()) {
		printf("The TCP/IP protocol stack is not loaded\n");
		exit(1);
	}
	for (x = 0; x < MAX_SOCKETS; x++) {
		in_use[x] = 0;
	}

	if ((s = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
		soperror("socket");
		exit(1);
	}

	bzero ((char *)&addr, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(ECHO_PORT);
	addr.sin_addr.s_addr = 0;

	if (bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		(void) soclose(s);
		soperror("bind");
		exit(1);
	}

	if (listen(s, 5) < 0) {
		(void) soclose(s);
		soperror("listen");
		exit(1);
	}

	printf("The TCP echo server is ready\n\n");

	for (;;) {

		FD_ZERO(&readfds);

		seltime.tv_sec = 1; seltime.tv_usec = 0;

		FD_SET(s, &readfds);
		for (x = 0; x < MAX_SOCKETS; x++) {
			if (in_use[x]) {
				FD_SET(x, &readfds);
			}
		}

		if (!select(MAX_SOCKETS,
			    &readfds, (fd_set *) 0, (fd_set *) 0,
			    &seltime)) {
			continue;
		}

		for (x = 0; x < MAX_SOCKETS; x++) {
			if (FD_ISSET(x, &readfds)) {
				if (x != s) {
					read_and_echo(x);
				} else {
					make_new_echo(x);
				}
			}
		}
	}
}

/*
 * Read and echo the input from a socket
 */

void 
read_and_echo(s)
	int             s;
{
	int             rc, len;

	if ((len = soread(s, buffer, sizeof(buffer))) <= 0) {
		printf("Closing socket #%d\n", s);
		in_use[s] = 0;
		(void) soclose(s);
	} else {
		rc = sowrite(s, buffer, len);
		if (rc < 0) {
			printf("Closing socket #%d\n", s);
			in_use[s] = 0;
			(void) soclose(s);
		}
	}
}

/*
 * Make a new socket using accept()
 */

void 
make_new_echo(s)
	int             s;
{
	int             ns;
	struct sockaddr_in peer;
	int             peersize = sizeof(peer);

	if ((ns = accept(s, (struct sockaddr *)&peer, &peersize)) < 0) {
		printf("Could not accept new connection\n");
		return;
	}

	in_use[ns] = 1;

	printf("Created socket #%d from %s:%d\n",
	       ns, inet_ntoa(peer.sin_addr), htons(peer.sin_port));
}
