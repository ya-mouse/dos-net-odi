/*
 * Example UDP server for DOS Lan Workplace 4.0 Transport Socket API.
 * 
 * It accepts datagrams on UDP port 7, reads data from the socket and 
 * echoes it back to the client.
 */

#include <windows.h>
#include <stdio.h>
#include <process.h>

#include <sys\socket.h>
#include "wudpserv.h"

long FAR PASCAL WUdpServWndProc(HWND, unsigned, WORD, LONG);
VOID AlertUser (HWND, LPSTR);
BOOL InitWindow(HANDLE);

HANDLE          hInst;
HANDLE          hLibInstance;

#define	ECHO_PORT	7
#define	BUFFER_SIZE	1024

int             on = 1;
char            buffer[BUFFER_SIZE];

char            szBuffer[256];	/* used for messages */


int PASCAL 
WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
	HANDLE          hInstance;
	HANDLE          hPrevInstance;
	LPSTR           lpCmdLine;
	int             nCmdShow;

{

	HWND            hWnd;
	MSG             msg;

	if (!hPrevInstance)
		if (!InitWindow(hInstance))
			return (NULL);

	hInst = hLibInstance = hInstance;

	hWnd = CreateWindow("TestClass",
			    "UDP Echo Server",
			    WS_OVERLAPPEDWINDOW,
			    CW_USEDEFAULT,
			    CW_USEDEFAULT,
			    CW_USEDEFAULT,
			    CW_USEDEFAULT,
			    NULL,
			    NULL,
			    hInstance,
			    NULL);

	if (!hWnd)
		return (NULL);

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	while (GetMessage(&msg, NULL, NULL, NULL)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return (msg.wParam);

}

VOID 
wudp_serv(hWnd)
	HWND            hWnd;

{
	int             s, len;
	struct sockaddr_in addr;
	struct sockaddr_in peer;
	int             remlen = sizeof(peer);
	char            szIPAddr[16];
	MSG		msg;

	if ((s = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		AlertUser(hWnd, (LPSTR) "socket failed");
		exit(1);
	}

	if (ioctl(s, FIONBIO, (CHARPTR) &on) < 0) {
		(void) soclose(s);
		AlertUser (hWnd, (LPSTR) "ioctl failed");
		exit(1);
	}

	addr.sin_family = AF_INET;
	addr.sin_port = htons(ECHO_PORT);
	addr.sin_addr.s_addr = 0;

	if (bind(s, (SADDR_PTR)&addr, sizeof(addr)) < 0) {
		(void) soclose(s);
		AlertUser(hWnd, (LPSTR) "bind failed");
		exit(1);
	}

	AlertUser(hWnd, (LPSTR) "UDP echo server started");

	peer.sin_family = AF_INET;

	for (;;) {

		len = recvfrom(s, (LPSTR) buffer, BUFFER_SIZE, 0, 
                       (SADDR_PTR)&peer, (LPINT)&remlen);

		if (GetErrno() == EWOULDBLOCK) {
			if (PeekMessage (&msg, NULL, 0, 0, PM_REMOVE)) {
				if (msg.message == WM_QUIT) {
					(void) soclose(s);
					return;
				}
				TranslateMessage (&msg);
				DispatchMessage (&msg);
			}
			continue;
		}

		if (len < 0) {
			AlertUser(hWnd, (LPSTR) "recvfrom failed");
			(void) soclose(s);
			exit(1);
		}

		if (sendto(s, (LPSTR) buffer, len, 0, 
                      (SADDR_PTR)&peer, sizeof(peer)) < 0) {
			AlertUser(hWnd, (LPSTR) "sendto failed");
			(void) soclose(s);
			exit(1);
		}
	}
}

long FAR PASCAL 
WUdpServWndProc(hWnd, message, wParam, lParam)
	HWND            hWnd;
	unsigned        message;
	WORD            wParam;
	LONG            lParam;

{
	FARPROC         lpProcAbout;
	HANDLE          hTemp;
	HANDLE          hHost;
	LPSTR           lpTemp;
	char            szIPAddr[16];
	char            szHost[32];

	switch (message) {

	case WM_COMMAND:
		switch (wParam) {

		case IDM_WUDPSERV:
			wudp_serv(hWnd);
			break;

		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		}
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;

	default:
		return (DefWindowProc(hWnd, message, wParam, lParam));
	}
	return (NULL);
}

void 
AlertUser(hWnd, lpszWarning)
	HWND            hWnd;
	LPSTR           lpszWarning;

{
	MessageBox(hWnd,
		   lpszWarning,
		   "UDP Server",
		   MB_OK | MB_ICONEXCLAMATION);

}				/* end Warning () */


BOOL 
InitWindow(hInstance)
	HANDLE          hInstance;

{
	WNDCLASS        WndClass;
	BOOL            bSuccess;

	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	WndClass.lpfnWndProc = WUdpServWndProc;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hInstance = hInstance;
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hbrBackground = COLOR_WINDOW + 1;
	WndClass.lpszMenuName = (LPSTR) "TestMenu";
	WndClass.lpszClassName = (LPSTR) "TestClass";

	return (RegisterClass((PWNDCLASS) & WndClass));
}

