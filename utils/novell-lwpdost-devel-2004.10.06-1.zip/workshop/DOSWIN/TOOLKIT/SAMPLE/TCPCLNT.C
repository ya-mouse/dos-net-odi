/*
 * Example TCP client for DOS Lan Workplace 4.0 Transport Socket API.
 * 
 * It opens a connection with an echo server at TCP port 7, sends data 
 * and waits for all data to be echoed before closing the socket.
 * 
 * To compile and link (using Microsoft C):
 * 
 *	cl /W3 tcpclnt.c /link slibsock.lib
 * 
 * 
 * To execute:
 * 
 *	tcpclnt <IP address>
 */

#include <stdio.h>
#include <process.h>

#include <sys/socket.h>

#define	ECHO_PORT	7
#define	NUM_PKTS	10
#define	BUFFER_SIZE	1024
#define	TOTAL_BYTES	NUM_PKTS * BUFFER_SIZE

char            buffer[BUFFER_SIZE];
struct timeval  seltime;
fd_set          readfds, writefds;
int             pkts_sent = 0;
int             bytes_recv = 0;

void            main(int, char **);

/*
 * Main routine
 */

void
main(argc, argv)
	int             argc;
	char          **argv;
{
	int             s, rc, len;
	char           *hostname = 0;
	unsigned long   remote_ip;
	struct sockaddr_in addr;


	if (!loaded()) {
		printf("The TCP/IP protocol stack is not loaded\n");
		exit(1);
	}
	if (argc != 2) {
		printf("usage: tcpclnt <IP address>\n");
		exit(1);
	}
	hostname = argv[1];
	if ((remote_ip = rhost(&hostname)) == -1) {
		printf("unknown or illegal hostname = %s", argv[1]);
		exit(1);
	}
	if ((s = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
		soperror("socket");
		exit(1);
	}

	bzero ((char *)&addr, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(ECHO_PORT);
	addr.sin_addr.s_addr = remote_ip;

	if (connect(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		(void) soclose(s);
		soperror("connect");
		exit(1);
	}

	while (bytes_recv < TOTAL_BYTES) {

		FD_ZERO(&readfds); FD_ZERO(&writefds);
		FD_SET(s, &readfds); FD_SET(s, &writefds);
		seltime.tv_sec = 0; seltime.tv_usec = 0;

		if (!select(s + 1,
			    &readfds, &writefds, (fd_set *) 0,
			    &seltime)) {
			continue;
		}

		if (pkts_sent < NUM_PKTS) {
			if (FD_ISSET(s, &writefds)) {
				rc = sowrite(s, buffer, BUFFER_SIZE);
				if (rc < 0) {
					(void) soclose(s);
					exit(1);
				}
				pkts_sent++;
			}
		}

		if (FD_ISSET(s, &readfds)) {
			if ((len = soread(s, buffer, BUFFER_SIZE)) > 0) {
				bytes_recv += len;
			}
		}
	}

	printf ("Sent and received %d bytes\n", TOTAL_BYTES);

	(void) soclose(s);
}
