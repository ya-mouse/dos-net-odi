/*
 * Example UDP server for DOS Lan Workplace 4.0 Transport Socket API.
 * 
 * It accepts datagrams on UDP port 7, reads data from the socket and 
 * echoes it back to the client.  This program never exits.
 * 
 * To compile and link (using Microsoft C):
 * 
 *	cl /W3 udpserv.c /link slibsock.lib
 * 
 * 
 * To execute:
 * 
 *	udpserv
 */

#include <stdio.h>
#include <process.h>

#include <sys/socket.h>

#define	ECHO_PORT	7
#define	BUFFER_SIZE	1024

char            buffer[BUFFER_SIZE];

void            main(void);

/*
 * Main routine
 */

void 
main()
{
	int	s, len;
	struct	sockaddr_in	addr;
	struct	sockaddr_in	peer;
	int	remlen = sizeof (peer);


	if (!loaded ()) {
		printf ("The TCP/IP protocol stack is not loaded\n");
		exit (1);
	}

	if ((s = socket (PF_INET, SOCK_DGRAM, 0)) < 0) {
		soperror ("socket");
		exit (1);
	}

	bzero ((char *)&addr, sizeof(addr));
	addr.sin_family      = AF_INET;
	addr.sin_port        = htons(ECHO_PORT);
	addr.sin_addr.s_addr = 0;

	if (bind (s, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		soperror ("bind");
		(void) soclose (s);
		exit (1);
	}

	printf("The UDP echo server is ready\n\n");

	bzero ((char *)&peer, sizeof(peer));
	peer.sin_family = AF_INET;

	for (;;) {

		len = recvfrom (s, buffer, BUFFER_SIZE, 0, 
                        (struct sockaddr *)&peer, &remlen);

		if (len < 0) {
			soperror ("recvfrom");
			(void) soclose (s);
			exit (1);
		}

		if (sendto (s, buffer, len, 0, (struct sockaddr *)&peer,
                                                sizeof(peer)) < 0) {
			soperror ("sendto");
			(void) soclose (s);
			exit (1);
		}

		printf("Returned a UDP datagram of length %d to %s:%d\n",
	       		len, inet_ntoa(peer.sin_addr), htons(peer.sin_port));
	}
}

